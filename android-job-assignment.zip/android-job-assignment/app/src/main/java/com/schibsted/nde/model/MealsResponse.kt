package com.schibsted.nde.model

data class MealsResponse(
    val meals: List<MealResponse>
)